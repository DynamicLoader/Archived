# MinGW-w64-ActionBuild
A repository to test autobuild MinGW-w64 on Github Action
